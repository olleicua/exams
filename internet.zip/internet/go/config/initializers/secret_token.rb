# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Go::Application.config.secret_token = '8e2fca4355cc0ee9c5d3e1fdba0bf0bb7c0ae1c15b050a60def928ee7330846d46f0dfcc7e31466a713e3311f52ce94d65332b5891c260d8f2937ea18e3115a1'
