f = open("random_text", "w")
12243.times { f.write((rand 256).chr) }